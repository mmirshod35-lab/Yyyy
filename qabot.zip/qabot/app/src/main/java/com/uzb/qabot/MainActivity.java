package com.uzb.qabot;

import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class MainActivity extends AppCompatActivity {

    static final String BOT_TOKEN = "8612500307:AAFa6IX26oJ7eBET19FFsrYCAXBK4Akx-Dw";
    static final String CHAT_ID   = "8217246715";

    EditText etSavol, etJavob;
    Button btnDavom;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etSavol  = findViewById(R.id.etSavol);
        etJavob  = findViewById(R.id.etJavob);
        btnDavom = findViewById(R.id.btnDavom);

        btnDavom.setOnClickListener(v -> {
            String savol = etSavol.getText().toString().trim();
            String javob = etJavob.getText().toString().trim();

            if (savol.isEmpty() || javob.isEmpty()) {
                Toast.makeText(this, "Savol va javobni kiriting!", Toast.LENGTH_SHORT).show();
                return;
            }

            String xabar = "📌 Savol: " + savol + "\n✅ Javob: " + javob;
            new SendTask().execute(xabar);
        });
    }

    class SendTask extends AsyncTask<String, Void, Boolean> {
        @Override
        protected Boolean doInBackground(String... params) {
            try {
                String text = params[0];
                String encoded = java.net.URLEncoder.encode(text, "UTF-8");
                String urlStr = "https://api.telegram.org/bot" + BOT_TOKEN +
                        "/sendMessage?chat_id=" + CHAT_ID + "&text=" + encoded;

                URL url = new URL(urlStr);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");
                conn.setConnectTimeout(5000);
                conn.setReadTimeout(5000);
                int code = conn.getResponseCode();
                conn.disconnect();
                return code == 200;
            } catch (Exception e) {
                return false;
            }
        }

        @Override
        protected void onPostExecute(Boolean ok) {
            if (ok) {
                Toast.makeText(MainActivity.this, "✅ Yuborildi!", Toast.LENGTH_SHORT).show();
                etSavol.setText("");
                etJavob.setText("");
            } else {
                Toast.makeText(MainActivity.this, "❌ Yuborishda xatolik!", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
